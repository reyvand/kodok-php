<?php
  //error_reporting(0);
	include 'include/connection.php';
	function getMonth($val) {
		$month = array('Januari','Februari','Maret','April','Mei','Juni','Juli','Agustus','September','Oktober','November','Desember');
		return $month[$val-1];
	}
	$q_cetak = "SELECT mhs_nama,mhs_nim,mhs_prodi,mhs_wisuda,tgl_ambil FROM cetak_rekom WHERE mhs_nim=?";
	$query = $link->prepare($q_cetak);
	if($query) {
		$query->bind_param('s',$link->real_escape_string($_GET['nim']));
		$query->execute();
		$res = $query->get_result();
		$r = $res->fetch_assoc();
	}
?>
<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="UTF-8">
	<title>Formulir Pengambilan Ijazah</title>
	<link rel="stylesheet" href="assets/css/style_formulir.css">
	<link rel="icon" href="assets/img/trisakti_logo_svg.png" sizes="16x16" type="image/png">
	<link href="https://fonts.googleapis.com/css?family=Open+Sans" rel="stylesheet"> 
</head>
<body>
	<div class="wrapper">
		<br><br>
		<div class="header">
			<img src="assets/img/trisakti_logo_svg.png" class="img-logo">
			<p class="text-logo">PROGRAM PASCASARJANA <br> UNIVERSITAS TRISAKTI </p>
		</div>
		<div class="main">
			<br>
			<div class="top">
				<center>FORMULIR</center>
				<center>PENGAMBILAN IJAZAH DAN TRANSKRIP NILAI</center>
			</div>
			<br><br>
			<div class="mid">
				<p>Dengan ini dinyatakan bahwa : </p><br><br>
				<table class="biodata">
					<tr>
						<td>N A M A</td><td>:</td>
						<td>&nbsp;&nbsp;<?= $r['mhs_nama'] ?></td>
					</tr>
					<tr>
						<td>N I M</td><td>:</td>
						<td>&nbsp;&nbsp;<?= $r['mhs_nim'] ?></td>
					</tr>
					<tr>
						<td>Program Studi&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</td><td>:</td>
						<td>&nbsp;&nbsp;Magister Manajemen</td>
					</tr>
					<tr>
						<td>Konsentrasi</td><td>:</td>
						<td>&nbsp;&nbsp;<?= $r['mhs_prodi'] ?></td>
					</tr>
					<?php
						$pecah = explode(' ', $r['mhs_wisuda']);
					?>
					<tr>
						<td>Wisuda</td><td>:</td>
						<td>&nbsp;&nbsp;Bulan <?= $pecah[0]; ?></td>
						<td>Tahun <?= $pecah[1]; ?></td>
					</tr>
				</table><br><br><br>
				<p>Telah menyerahkan 2 (dua) exemplar <b><i>TESIS</i></b> yang telah ditandatangani oleh Panitia Ujian Tesis serta 1 (satu) <b><i>Copy CD-TESIS</i></b>. Oleh karena itu yang bersangkutan dapat diberikan <b>Ijazah</b> dan <b>Transkrip Nilai</b></p>
			</div>
			<br><br>
			<div class="bot">
				<?php
					$bla = explode('-', $r['tgl_ambil']);
				?>
				<div class="date">
					<p>Jakarta, <?= $bla[0]." ".getMonth($bla[1])." ".$bla[2]; ?></p>
				</div>
				<div class="headof">
					<p>Dra.Saraswati, MM.</p><span style="margin-left: 1em;">Ka. Perpustakaan</span>
				</div>
			</div>
		</div>
		<div class="footer">
			<p><i><b><u>Perhatian !</u></b></i></p><br>
			<p>1. Pengambilan Ijazah Senin s/d Jumat (09:30 - 15:00 WIB)</p>
			<p>2. Ijazah dapat diambil 3 (tiga) bulan setelah wisuda</p>
		</div>
		
	</div>
	<script> window.print(); window.location=('index.php'); </script>
</body>
</html>