<?php
  error_reporting(0);
	include 'include/connection.php';
  if(isset($_POST['submit'])) {
    $q_ambil_ijazah = "INSERT INTO mm_ijazah_db.tb_ambil_ijazah (tgl_ambil,mhs_angkatan,mhs_nama,mhs_wisuda,mhs_telp_rumah,mhs_jabatan_pekerjaan,mhs_alamat_kantor,mhs_email) 
        VALUES (?,?,?,?,?,?,?,?)";
    $q_serah_tesis = "INSERT INTO mm_ijazah_db.tb_serah_tesis (mhs_nim,mhs_nama,mhs_prodi,mhs_wisuda,mhs_alamat_rumah,mhs_alamat_kantor,mhs_telp_rumah,mhs_telp_kantor,mhs_tesis_jml,mhs_tesis_cd,mhs_tanggal)
        VALUES (?,?,?,?,?,?,?,?,?,?,?)";
    $act_ambil = $link->prepare($q_ambil_ijazah);
    $act_serah = $link->prepare($q_serah_tesis);
    if($act_ambil) {
      $act_ambil->bind_param('ssssssss',$_POST['tgl'],
                                        $link->real_escape_string($_POST['angkatan']),
                                        $link->real_escape_string($_POST['mhs_nama']),
                                        $link->real_escape_string($_POST['mhs_wisuda']),
                                        $link->real_escape_string($_POST['no_telp']),
                                        $link->real_escape_string($_POST['mhs_jabatan']),
                                        $link->real_escape_string($_POST['alamat_kantor']),
                                        $link->real_escape_string($_POST['mhs_email']));
      $exec1 = $act_ambil->execute();
      if($exec1) {
        $act_serah->bind_param('sssssssssss',$link->real_escape_string($_POST['mhs_nim']),
                                             $link->real_escape_string($_POST['mhs_nama']),
                                             $link->real_escape_string($_POST['konsentrasi']),
                                             $link->real_escape_string($_POST['mhs_wisuda']),
                                             $link->real_escape_string($_POST['alamat_rumah']),
                                             $link->real_escape_string($_POST['alamat_kantor']),
                                             $link->real_escape_string($_POST['no_telp']),
                                             $link->real_escape_string($_POST['no_kantor']),
                                             $link->real_escape_string($_POST['tesis_jml']),
                                             $link->real_escape_string($_POST['tesis_cd']),
                                             $_POST['tgl']);
        $exec2 = $act_serah->execute();
        if($exec2) {
          $status = '<div class="ui success message"><div class="header">Pengisian Data Sukses</div><p>Silahkan lanjutkan ke pencetakan Surat Rekomendasi <a href="print_rekom.php?nim='.$_POST['mhs_nim'].'">disini</a></p></div>';
        } else {
          $status = '<div class="ui negative message"><div class="header">Pengisian Data Gagal</div><p>Harap coba lagi dalam beberapa saat atau hubungi Petugas</p></div>';
        }
      }
    }
  }
?>
<!DOCTYPE html>
<html>
<head>
  <!-- Standard Meta -->
  <meta charset="utf-8" />
  <meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0">

  <!-- Site Properties -->
  <title>Magister Manajemen | Pengambilan Ijazah</title>
  <link rel="stylesheet" type="text/css" href="assets/semantic/semantic.css">
  <link rel="icon" href="assets/img/trisakti_logo_svg.png" sizes="16x16" type="image/png">

  <script src="assets/lib/jquery-3.1.1.js"></script>
  <script src="assets/semantic/semantic.js"></script>
  
</head>
<body>

<h1 class="ui center aligned header">Form Pengisian Pengambilan Ijazah</h1>
<h2 class="ui center aligned header">Magister Manajemen</h2>
<div class="ui container">

  <div class="field">
    <?= $status; ?>
  </div><br><br>
  <form class="ui large form" action="" method="post">
	 	<div class="field">
	   	<label><i class="calendar icon"></i>Tanggal</label>
	   	<input name="tgl" type="text" readonly value="<?= date('d-m-Y') ?>">
	 	</div>
	 	<div class="field">
	   	<label><i class="file text outline icon"></i>NIM</label>
	   	<input name="mhs_nim" placeholder="Nomor Induk Mahasiswa" type="text" maxlength="10">
	 	</div>
	 	<div class="field">
	   	<label><i class="student icon"></i>Angkatan</label>
	   	<input name="angkatan" placeholder="Angkatan" type="text" maxlength="4">
	 	</div>
	 	<div class="field">
	   	<label><i class="user icon"></i>Nama</label>
	   	<input name="mhs_nama" placeholder="Nama Lengkap" type="text" maxlength="60">
	 	</div>
	 	<div class="two wide field">
    	<label>Konsentrasi</label>
    	<select class="ui search dropdown" name="konsentrasi">
      	<option value="Magister Manajemen">Magister Manajemen</option>
      	<option value="MM TELL">MM. Tell</option>
      	<option value="MM Komunikasi">MM. Komunikasi</option>
        <option value="Service Management">Service Management</option>
        <option value="MM CSR">MM CSR</option>
        <option value="Logistik">Logistik</option>
    	</select>
  	</div>
	  <div class="field">
	   	<label><i class="student icon"></i>Wisuda</label>
	   	<input name="mhs_wisuda" placeholder="Bulan & Tahun Wisuda [ex: September 2016]" type="text" maxlength="20">
	 	</div>
	 	<div class="ui small form">
		  <div class="two fields">
		    <div class="field">
		      <label style="font-size: 13px;"><i class="address book outline icon"></i>TESIS (Jml)</label>
		      <input name="tesis_jml" placeholder="Jml Tesis" type="text">
		    </div>
		    <div class="field">
		      <label style="font-size: 13px;"><i class="address book outline icon"></i>TESIS (CD)</label>
		      <input name="tesis_cd" placeholder="CD Tesis" type="text">
		    </div>
		  </div>
		</div>
		<div class="ui small form">
			<div class="two fields">
				<div class="field">
					<label style="font-size: 13px;"><i class="home icon"></i>Alamat Rumah</label>
					<textarea name="alamat_rumah"></textarea>
				</div>
				<div class="field">
					<label style="font-size: 13px;"><i class="home icon"></i>Alamat Kantor</label>
					<textarea name="alamat_kantor"></textarea>
				</div>
			</div>
		</div>
		<div class="ui small form">
		  <div class="two fields">
		    <div class="field">
		      <label style="font-size: 13px;"><i class="text telephone icon"></i>No Telp</label>
		      <input name="no_telp" placeholder="Nomor Telepon" type="text">
		    </div>
		    <div class="field">
		      <label style="font-size: 13px;"><i class="text telephone icon"></i>No Telp Kantor</label>
		      <input name="no_kantor" placeholder="Nomor Telepon Kantor" type="text">
		    </div>
		  </div>
		</div>
		<div class="field">
      <label><i class="mail outline icon"></i>Jabatan Pekerjaan</label>
      <input name="mhs_jabatan" placeholder="Jabatan Pekerjaan" type="text" maxlength="60">
    </div>
    <div class="field">
	   	<label><i class="mail outline icon"></i>Email</label>
	   	<input name="mhs_email" placeholder="Alamat Email" type="text" maxlength="60">
	 	</div>
	 	<button class="ui blue large button" name="submit" onclick="return confirm('Apakah data yang diisi sudah benar ?')"><i class="add user icon"></i>Submit</button>
	</form>
</div>
<style>
  .last.container {
    margin-bottom: 300px !important;
  }
  h1.ui.center.header {
    margin-top: 0.5em;
  }
  h2.ui.center.header {
    margin: 1em 0em 2em;
  }
  h3.ui.center.header {
    margin-top: 2em;
    padding: 2em 0em;
  }
  form.ui.large.form {
  	margin-bottom: 4em;
  }
</style>

<script type="text/javascript">
$(document).ready(function() {

  var
    $headers     = $('body > h3'),
    $header      = $headers.first(),
    ignoreScroll = false,
    timer
  ;

  // Preserve example in viewport when resizing browser
  $(window)
    .on('resize', function() {
      // ignore callbacks from scroll change
      clearTimeout(timer);
      $headers.visibility('disable callbacks');

      // preserve position
      $(document).scrollTop( $header.offset().top );

      // allow callbacks in 500ms
      timer = setTimeout(function() {
        $headers.visibility('enable callbacks');
      }, 500);
    })
  ;
  $headers
    .visibility({
      // fire once each time passed
      once: false,

      // don't refresh position on resize
      checkOnRefresh: true,

      // lock to this element on resize
      onTopPassed: function() {
        $header = $(this);
      },
      onTopPassedReverse: function() {
        $header = $(this);
      }
    })
  ;
  $('.ui.radio.checkbox')
  	.checkbox()
	;
	$('select.dropdown')
    .dropdown()
  	;
});
</script>

</body>
</html>