<?php

	$link = new mysqli('localhost','root','yz!((*qwe','mm_ijazah_db');
	if($link->connect_error) {
		echo '<code style="color:red;display:block;">failed while connecting into database</code>';
		return false;
	}