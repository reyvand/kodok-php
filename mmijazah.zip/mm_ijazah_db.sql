-- phpMyAdmin SQL Dump
-- version 4.5.2
-- http://www.phpmyadmin.net
--
-- Host: localhost
-- Generation Time: Mar 27, 2017 at 04:32 
-- Server version: 10.1.19-MariaDB
-- PHP Version: 7.0.9

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `mm_ijazah_db`
--

-- --------------------------------------------------------

--
-- Stand-in structure for view `cetak_rekom`
--
CREATE TABLE `cetak_rekom` (
`id` int(11)
,`mhs_nama` varchar(60)
,`mhs_nim` varchar(10)
,`mhs_prodi` varchar(30)
,`mhs_wisuda` varchar(20)
,`tgl_ambil` varchar(10)
);

-- --------------------------------------------------------

--
-- Stand-in structure for view `mm_alumni`
--
CREATE TABLE `mm_alumni` (
`id` int(11)
,`mhs_nim` varchar(10)
,`mhs_nama` varchar(60)
,`mhs_prodi` varchar(30)
,`mhs_tanggal` varchar(10)
,`mhs_alamat_rumah` text
,`mhs_alamat_kantor` text
,`mhs_angkatan` varchar(11)
,`mhs_telp_rumah` varchar(15)
,`mhs_email` varchar(60)
);

-- --------------------------------------------------------

--
-- Table structure for table `tb_ambil_ijazah`
--

CREATE TABLE `tb_ambil_ijazah` (
  `id` int(11) NOT NULL,
  `tgl_ambil` varchar(10) NOT NULL,
  `mhs_angkatan` varchar(11) NOT NULL,
  `mhs_nama` varchar(60) NOT NULL,
  `mhs_wisuda` varchar(20) NOT NULL,
  `mhs_telp_rumah` varchar(15) NOT NULL,
  `mhs_jabatan_pekerjaan` varchar(30) NOT NULL,
  `mhs_alamat_kantor` text NOT NULL,
  `mhs_email` varchar(60) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tb_ambil_ijazah`
--

INSERT INTO `tb_ambil_ijazah` (`id`, `tgl_ambil`, `mhs_angkatan`, `mhs_nama`, `mhs_wisuda`, `mhs_telp_rumah`, `mhs_jabatan_pekerjaan`, `mhs_alamat_kantor`, `mhs_email`) VALUES
(1, '06-03-2017', '12', 'qwe', 'Maret 2017', '123', 'a', 'zxczxc', 'a@mail.me'),
(2, '06-03-2017', '31', 'asd', 'Mei 2017', '321321321', 'QQW', 'qwertyuiopasdfghjkl', 'z@mail.me'),
(3, '07-03-2017', '12', 'asdasd', 'Januari 2017', '1231231', 'qweqwe', 'asd asdasd asd', 'zx@mail.me'),
(4, '10-03-2017', '12', 'asdasdsd', 'Januari 2016', '123213', 'qweqwe', 'asdasdasdasdasdasdasdasdasdasdasdasd', 'me@mail.me');

-- --------------------------------------------------------

--
-- Table structure for table `tb_serah_tesis`
--

CREATE TABLE `tb_serah_tesis` (
  `mhs_nim` varchar(10) NOT NULL,
  `mhs_nama` varchar(60) NOT NULL,
  `mhs_prodi` varchar(30) NOT NULL,
  `mhs_wisuda` varchar(20) NOT NULL,
  `mhs_alamat_rumah` text NOT NULL,
  `mhs_alamat_kantor` text NOT NULL,
  `mhs_telp_rumah` varchar(15) NOT NULL,
  `mhs_telp_kantor` varchar(15) NOT NULL,
  `mhs_tesis_jml` varchar(3) NOT NULL,
  `mhs_tesis_cd` varchar(3) NOT NULL,
  `mhs_tanggal` varchar(10) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tb_serah_tesis`
--

INSERT INTO `tb_serah_tesis` (`mhs_nim`, `mhs_nama`, `mhs_prodi`, `mhs_wisuda`, `mhs_alamat_rumah`, `mhs_alamat_kantor`, `mhs_telp_rumah`, `mhs_telp_kantor`, `mhs_tesis_jml`, `mhs_tesis_cd`, `mhs_tanggal`) VALUES
('123123', 'asdasd', 'Logistik', 'Januari 2017', 'asd asdasd asdasd asdasd asd', 'asd asdasd asd', '1231231', '321', '23', 'qwe', '07-03-2017'),
('1231231', 'qwe', 'Magister Manajemen', 'Maret 2017', 'asdasd', 'zxczxc', '123', '321', '1', 'qaw', '06-03-2017'),
('123123123', 'asdasdsd', 'Magister Manajemen', 'Januari 2016', 'asdasdasdasdasdasdasdasdasdasd', 'asdasdasdasdasdasdasdasdasdasdasdasd', '123213', '321321', '1', 'asd', '10-03-2017'),
('321', 'asd', 'Service Management', 'Mei 2017', 'qwertyuiopasdfghjkl', 'qwertyuiopasdfghjkl', '321321321', '1231231', '1', 'ABC', '06-03-2017');

-- --------------------------------------------------------

--
-- Structure for view `cetak_rekom`
--
DROP TABLE IF EXISTS `cetak_rekom`;

CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `cetak_rekom`  AS  select `tb_ambil_ijazah`.`id` AS `id`,`tb_ambil_ijazah`.`mhs_nama` AS `mhs_nama`,`tb_serah_tesis`.`mhs_nim` AS `mhs_nim`,`tb_serah_tesis`.`mhs_prodi` AS `mhs_prodi`,`tb_ambil_ijazah`.`mhs_wisuda` AS `mhs_wisuda`,`tb_ambil_ijazah`.`tgl_ambil` AS `tgl_ambil` from (`tb_ambil_ijazah` join `tb_serah_tesis` on((`tb_ambil_ijazah`.`mhs_nama` = `tb_serah_tesis`.`mhs_nama`))) ;

-- --------------------------------------------------------

--
-- Structure for view `mm_alumni`
--
DROP TABLE IF EXISTS `mm_alumni`;

CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `mm_alumni`  AS  select `tb_ambil_ijazah`.`id` AS `id`,`tb_serah_tesis`.`mhs_nim` AS `mhs_nim`,`tb_serah_tesis`.`mhs_nama` AS `mhs_nama`,`tb_serah_tesis`.`mhs_prodi` AS `mhs_prodi`,`tb_serah_tesis`.`mhs_tanggal` AS `mhs_tanggal`,`tb_serah_tesis`.`mhs_alamat_rumah` AS `mhs_alamat_rumah`,`tb_serah_tesis`.`mhs_alamat_kantor` AS `mhs_alamat_kantor`,`tb_ambil_ijazah`.`mhs_angkatan` AS `mhs_angkatan`,`tb_ambil_ijazah`.`mhs_telp_rumah` AS `mhs_telp_rumah`,`tb_ambil_ijazah`.`mhs_email` AS `mhs_email` from (`tb_serah_tesis` join `tb_ambil_ijazah` on((`tb_serah_tesis`.`mhs_nama` = `tb_ambil_ijazah`.`mhs_nama`))) ;

--
-- Indexes for dumped tables
--

--
-- Indexes for table `tb_ambil_ijazah`
--
ALTER TABLE `tb_ambil_ijazah`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `tb_serah_tesis`
--
ALTER TABLE `tb_serah_tesis`
  ADD PRIMARY KEY (`mhs_nim`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `tb_ambil_ijazah`
--
ALTER TABLE `tb_ambil_ijazah`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
