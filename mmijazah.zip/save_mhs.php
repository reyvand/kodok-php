<?php 

	include 'include/connection.php';
	if(isset($_POST['submit'])) {
		$q_ins_1 = 
	}
?>