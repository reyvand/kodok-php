<?php 
	include '../include/connection.php';
?>
<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="UTF-8">
	<meta charset="utf-8" />
  <meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0">

  <!-- Site Properties -->
  <link rel="stylesheet" type="text/css" href="../assets/semantic/semantic.css">
  <link rel="icon" href="../assets/img/trisakti_logo_svg.png" sizes="16x16" type="image/png">

  <script src="../assets/lib/jquery-3.1.1.js"></script>
  <script src="../assets/semantic/semantic.js"></script>
	<title>Data Pengambilan Ijazah Mahasiswa</title>
</head>
<h1 class="ui center aligned header">Data Mahasiswa Pengambil Ijazah</h1>
<h2 class="ui center aligned header">Magister Manajemen</h2>
<div class="ui container">
	<div class="ui twelve column grid">
    <table class="ui selectable celled table">
		  <thead class="full width">
		    <tr>
		      <th>No</th>
		      <th>Nama</th>
		      <th>NIM</th>
		      <th>Angkatan</th>
		      <th>Prodi</th>
		      <th>Alamat Rumah</th>
		      <th>Alamat Kantor</th>
		      <th>No Telepon</th>
		      <th>Email</th>
		      <th>Tgl Ambil</th>
		    </tr>
		  </thead>
		  <tbody>
		  <?php 
		  	$q = "SELECT * FROM mm_alumni";
		  	$act = $link->prepare($q);
		  	if($act) {
		  		$act->execute();
		  		$res = $act->get_result();
		  		while($r = $res->fetch_assoc()) {
		  			echo "<tr>
		  							<td>".$r['id']."</td>
		  							<td>".$r['mhs_nama']."</td>
		  							<td>".$r['mhs_nim']."</td>
		  							<td>".$r['mhs_angkatan']."</td>
		  							<td>".$r['mhs_prodi']."</td>
		  							<td>".$r['mhs_alamat_rumah']."</td>
		  							<td>".$r['mhs_alamat_kantor']."</td>
		  							<td>".$r['mhs_telp_rumah']."</td>
		  							<td>".$r['mhs_email']."</td>
		  							<td>".$r['mhs_tanggal']."</td>
		  						</tr>";
		  		}
		  	}
		  ?>
		  </tbody>
		</table>
  </div>
</div>
<style>
  .last.container {
    margin-bottom: 300px !important;
  }
  h1.ui.center.header {
    margin-top: 0.5em;
  }
  h2.ui.center.header {
    margin: 1em 0em 2em;
  }
  h3.ui.center.header {
    margin-top: 2em;
    padding: 2em 0em;
  }
  form.ui.large.form {
  	margin-bottom: 4em;
  }
</style>
</body>
</html>